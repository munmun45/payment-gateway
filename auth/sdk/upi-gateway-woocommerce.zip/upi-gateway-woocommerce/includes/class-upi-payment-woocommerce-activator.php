<?php

/**
 * Fired during plugin activation
 *
 * @link      cxrhosting.in
 * @since      1.0.0
 *
 * @package    Upi_Payment_Woocommerce
 * @subpackage Upi_Payment_Woocommerce/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Upi_Payment_Woocommerce
 * @subpackage Upi_Payment_Woocommerce/includes
 * @author     cxr<team@cxrhosting.in>
 */
class Upi_Payment_Woocommerce_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
