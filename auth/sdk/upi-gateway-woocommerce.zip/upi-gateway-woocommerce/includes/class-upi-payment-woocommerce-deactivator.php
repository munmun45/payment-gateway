<?php

/**
 * Fired during plugin deactivation
 *
 * @link       team@cxrhosting.in
 * @since      1.0.0
 *
 * @package    Upi_Payment_Woocommerce
 * @subpackage Upi_Payment_Woocommerce/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Upi_Payment_Woocommerce
 * @subpackage Upi_Payment_Woocommerce/includes
 * @author     team@cxrhosting.in
 */
class Upi_Payment_Woocommerce_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
